export interface FileUploadProps {
  onFileSelect: (file: File) => void;
  accept: string;
  label: string;
}

export interface AnalysisResult {
  prediction: string;
  confidence: number;
}