import React, { useState } from 'react';
import { Microscope } from 'lucide-react';
import FileUpload from './components/FileUpload';
import ResultDisplay from './components/ResultDisplay';
import type { AnalysisResult } from './types';
import Papa from 'papaparse';

function App() {
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const processFile = async (file: File) => {
    setIsProcessing(true);
    
    // Simulate processing with a mock analysis
    // In a real application, this would connect to a backend service
    setTimeout(() => {
      const mockResult: AnalysisResult = {
        prediction: Math.random() > 0.5 ? 'positive' : 'negative',
        confidence: 0.7 + Math.random() * 0.2
      };
      setResult(mockResult);
      setIsProcessing(false);
    }, 2000);
  };

  const handleFileSelect = (file: File) => {
    if (file.type === 'text/csv') {
      Papa.parse(file, {
        complete: (results) => {
          console.log('CSV Data:', results.data);
          processFile(file);
        },
        error: (error) => {
          console.error('Error parsing CSV:', error);
        }
      });
    } else {
      processFile(file);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-4">
            <Microscope className="h-12 w-12 text-blue-600" />
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Cancer Blood Detection Analysis
          </h1>
          <p className="text-lg text-gray-600">
            Upload your blood smear image or CSV data for instant analysis
          </p>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-8">
          <div className="grid gap-8 md:grid-cols-2">
            <div>
              <h2 className="text-xl font-semibold mb-4">Upload Image</h2>
              <FileUpload
                onFileSelect={handleFileSelect}
                accept="image/*"
                label="Upload blood smear image"
              />
            </div>
            <div>
              <h2 className="text-xl font-semibold mb-4">Upload CSV Data</h2>
              <FileUpload
                onFileSelect={handleFileSelect}
                accept=".csv"
                label="Upload blood test CSV data"
              />
            </div>
          </div>

          {isProcessing && (
            <div className="mt-8 text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto"></div>
              <p className="mt-4 text-gray-600">Analyzing your data...</p>
            </div>
          )}

          <ResultDisplay result={result} />

          <div className="mt-8 border-t pt-6">
            <h3 className="text-lg font-semibold mb-2">Important Notice</h3>
            <p className="text-sm text-gray-600">
              This tool is designed for preliminary screening purposes only. The results should not be
              considered as a definitive medical diagnosis. Always consult with qualified healthcare
              professionals for proper medical evaluation and diagnosis.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;