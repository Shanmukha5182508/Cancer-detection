import React from 'react';
import { CheckCircle, XCircle } from 'lucide-react';
import type { AnalysisResult } from '../types';

interface ResultDisplayProps {
  result: AnalysisResult | null;
}

const ResultDisplay: React.FC<ResultDisplayProps> = ({ result }) => {
  if (!result) return null;

  const isPositive = result.prediction === 'positive';

  return (
    <div className={`mt-8 p-6 rounded-lg ${isPositive ? 'bg-red-50' : 'bg-green-50'}`}>
      <div className="flex items-center">
        {isPositive ? (
          <XCircle className="h-8 w-8 text-red-500" />
        ) : (
          <CheckCircle className="h-8 w-8 text-green-500" />
        )}
        <div className="ml-4">
          <h3 className={`text-lg font-semibold ${isPositive ? 'text-red-800' : 'text-green-800'}`}>
            {isPositive ? 'Potential Cancer Indicators Detected' : 'No Cancer Indicators Detected'}
          </h3>
          <p className="text-sm mt-1 text-gray-600">
            Confidence: {(result.confidence * 100).toFixed(2)}%
          </p>
        </div>
      </div>
      <p className="mt-4 text-sm text-gray-600">
        Please note: This is a preliminary screening tool. Consult with healthcare professionals for proper diagnosis and treatment.
      </p>
    </div>
  );
};

export default ResultDisplay;